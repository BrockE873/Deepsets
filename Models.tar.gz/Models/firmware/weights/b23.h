//Numpy array shape [1]
//Min -0.031250000000
//Max -0.031250000000
//Number of zeros 0

#ifndef B23_H_
#define B23_H_

#ifndef __SYNTHESIS__
bias23_t b23[1];
#else
bias23_t b23[1] = {-0.0312500};
#endif

#endif
