//Numpy array shape [12]
//Min -0.346930682659
//Max 0.822206556797
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
batchnorm_default_t b2[12];
#else
batchnorm_default_t b2[12] = {0.82220655680, -0.16359347105, 0.02518008463, 0.03276378661, -0.00671319431, -0.20106647909, -0.34693068266, 0.53988772631, -0.01149835251, 0.00001174770, -0.08764502406, -0.28540444374};
#endif

#endif
