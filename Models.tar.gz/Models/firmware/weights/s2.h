//Numpy array shape [12]
//Min 0.009245525114
//Max 31.622774124146
//Number of zeros 0

#ifndef S2_H_
#define S2_H_

#ifndef __SYNTHESIS__
batchnorm_default_t s2[12];
#else
batchnorm_default_t s2[12] = {1.50868546963, 17.74454498291, 31.62277412415, 31.62277412415, 31.62277412415, 4.32280635834, 3.15669655800, 1.00232350826, 0.67637628317, 0.23458930850, 0.00924552511, 0.02816604078};
#endif

#endif
